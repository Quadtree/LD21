package litd.server.itemfactory;

import litd.shared.ItemStats;

public abstract class ItemTemplate {
	public abstract void modify(ItemStats item);
}
