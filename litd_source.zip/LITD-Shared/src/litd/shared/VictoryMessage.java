package litd.shared;

import java.io.Serializable;

public class VictoryMessage implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 914434504960262220L;

}
