package litd.shared;

import java.io.Serializable;

public class PickupCommand implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7392128742566495120L;

}
