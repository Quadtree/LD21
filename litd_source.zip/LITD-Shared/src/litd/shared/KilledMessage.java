package litd.shared;

import java.io.Serializable;

public class KilledMessage implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6568236317870149063L;

}
