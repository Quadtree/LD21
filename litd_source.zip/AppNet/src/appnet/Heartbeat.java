package appnet;

import java.io.Serializable;

public class Heartbeat implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6859216343382511835L;

}
