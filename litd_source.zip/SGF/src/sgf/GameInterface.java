package sgf;

public interface GameInterface {
	public void init();
	public void render();
	public void update();
	public void shutdown();
}
