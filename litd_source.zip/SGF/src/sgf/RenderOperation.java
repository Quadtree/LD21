package sgf;

import java.awt.Graphics2D;

public abstract class RenderOperation {
	public abstract void execute(Graphics2D g);
}
